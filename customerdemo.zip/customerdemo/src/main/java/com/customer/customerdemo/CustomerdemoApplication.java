package com.customer.customerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerdemoApplication.class, args);
	}

}
