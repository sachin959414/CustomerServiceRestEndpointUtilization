package com.customer.customerdemo.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.customer.customerdemo.demo.CustomerBean;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class CustomerController {
	String token = "dGVzdEBzdW5iYXNlZGF0YS5jb206VGVzdEAxMjM=";

	RestTemplate rest = new RestTemplateBuilder().build();

	@GetMapping("/loginPage")
	public String loginpage() {
		return "login";
	}

	@GetMapping("/")
	public String start() {
		return "login";
	}

	@PostMapping("/login")
	public ResponseEntity<String> login(HttpServletRequest req) {
		String username = req.getParameter("Username");
		String password = req.getParameter("Password");
		String t = (String) req.getSession(true).getAttribute("token");
		if (username.equals("test@sunbasedata.com") && password.equals("Test@123")) {
			try {
				System.out.println("inside iffff");
				if ((null == t || t.isEmpty())) {
					String url = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment_auth.jsp";
					Map<String, String> params = new HashMap();
					params.put("login_id", username);
					params.put("password", password);
					// here depending on the status if we got positive response without any exception then we will perform operation else it will go to catch  block
					String token = this.rest.postForObject(url, params, String.class);
					String tokensplit[] = token.split(":");
					System.out.println("before " + token);
					req.getSession().setAttribute("token", tokensplit[1].substring(1, tokensplit[1].length() - 3));
					System.out.println("after " + tokensplit[1].substring(1, tokensplit[1].length() - 3));
				}
				// System.out.println("jjj "+token);
				return new ResponseEntity<String>("Success", HttpStatus.OK);
			} catch (Exception e) {
				// TODO: handle exception
				return new ResponseEntity<String>("fail", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			System.out.println("javaaaaa ");
			return new ResponseEntity<String>("Failed ", HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping("/createcustomerpage")
	public String createCustomerPage() {
		return "createCustomer";
	}

	@PostMapping("/addCustomer")
	public String addCustomer(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String token = (String) req.getSession().getAttribute("token");
		if (null != token || !token.isEmpty()) {
			try {
				String firstname = req.getParameter("firstname");
				String lastname = req.getParameter("firstname");
				String street = req.getParameter("street");
				String address = req.getParameter("address");
				String city = req.getParameter("city");
				String state = req.getParameter("state");
				String email = req.getParameter("email");
				String phone = req.getParameter("phone");
				RestTemplate restTemplate = new RestTemplate();
				restTemplate.getInterceptors().add((outReq, bytes, clientHttpReqExec) -> {
					outReq.getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer " + token);
					return clientHttpReqExec.execute(outReq, bytes);
				});
				Map<String, String> params = new HashMap();
				params.put("first_name", firstname);
				params.put("last_name", lastname);
				params.put("street", street);
				params.put("address", address);
				params.put("city", city);
				params.put("state", state);
				params.put("email", email);
				params.put("phone", phone);
				String url = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=create";
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<Object> entity = new HttpEntity<>(params, headers);
				// here depending on the status if we got positive response without any
				// exception then we will perform operation else it will go to catch block
				ResponseEntity<String> status = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				System.out.println(" hello " + status.getStatusCodeValue());
				res.sendRedirect(req.getContextPath() + "/customerpage");
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
				return "createCustomer";
			}
		}
		return "login";
	}

	@GetMapping("/customerpage")
	public ModelAndView customerPage(HttpServletRequest req, ModelAndView m) {
		System.out.println("jjjjjjjjjjjjjj");
		m = new ModelAndView("customerPage");
		String token = (String) req.getSession().getAttribute("token");
		System.out.println("session token " + token);
		try {
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.getInterceptors().add((outReq, bytes, clientHttpReqExec) -> {
				outReq.getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer " + token);
				return clientHttpReqExec.execute(outReq, bytes);
			});
			String url = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=get_customer_list";
			CustomerBean[] custsArray = restTemplate.getForObject(url, CustomerBean[].class);

			List<CustomerBean> custs = Arrays.asList(custsArray);
			m.addObject("customerlist", custs);
			System.out.println(custs);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			return new ModelAndView("login");
		}
		return m;
	}

	@GetMapping("/deletecustomer")
	public String deleteCustomer(@RequestParam(name = "uuid") String uuid, HttpServletRequest req,
			HttpServletResponse res) throws IOException {

		String t = (String) req.getSession(true).getAttribute("token");
		try {
			if ((null != t || !t.isEmpty())) {
				RestTemplate restTemplate = new RestTemplate();
				restTemplate.getInterceptors().add((outReq, bytes, clientHttpReqExec) -> {
					outReq.getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer " + t);
					return clientHttpReqExec.execute(outReq, bytes);
				});

				String url = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=delete";
				Map<String, String> params = new HashMap();
				params.put("uuid", uuid);
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<Object> entity = new HttpEntity<>(params, headers);
				// here depending on the status if we got positive response without any
				// exception then we will perform operation else it will go to catch block
				ResponseEntity<String> deleted = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				System.out.println(deleted);
				res.sendRedirect(req.getContextPath() + "/customerpage");
			} else {
				return "login";
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("not able to delete " + e);
			res.sendRedirect(req.getContextPath() + "/customerpage");
		}
		// System.out.println("jjj "+token);
		return "login";
	}

	@GetMapping("/updatecustomerpage")
	public ModelAndView updateCustomerPage(@RequestParam(name = "uuid") String uuid,
			@RequestParam(name = "first_name") String firstname, @RequestParam(name = "last_name") String lastname,
			@RequestParam(name = "street") String street, @RequestParam(name = "address") String address,
			@RequestParam(name = "city") String city, @RequestParam(name = "state") String state,
			@RequestParam(name = "email") String email, @RequestParam(name = "phone") String phone, ModelAndView m) {

		CustomerBean cust = new CustomerBean();
		cust.setUuid(uuid);
		cust.setFirst_name(firstname);
		cust.setLast_name(lastname);
		cust.setStreet(street);
		cust.setAddress(address);
		cust.setCity(city);
		cust.setState(state);
		cust.setEmail(email);
		cust.setPhone(phone);
		m = new ModelAndView("updatecustomerpage");
		m.addObject("customer", cust);
		System.out.println(uuid + " " + firstname + " " + lastname + " " + street + " " + address + " " + city + " "
				+ state + " " + email + " " + phone);
		return m;
	}

	@PostMapping("/updatecustomer")
	public String updateCustomer(HttpServletRequest req, HttpServletResponse res) {
		String token = (String) req.getSession().getAttribute("token");
		if (null != token || !token.isEmpty()) {
			try {
				String uuid = req.getParameter("uuid");
				String firstname = req.getParameter("firstname");
				String lastname = req.getParameter("firstname");
				String street = req.getParameter("street");
				String address = req.getParameter("address");
				String city = req.getParameter("city");
				String state = req.getParameter("state");
				String email = req.getParameter("email");
				String phone = req.getParameter("phone");
				RestTemplate restTemplate = new RestTemplate();
				restTemplate.getInterceptors().add((outReq, bytes, clientHttpReqExec) -> {
					outReq.getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer " + token);
					return clientHttpReqExec.execute(outReq, bytes);
				});
				Map<String, String> params = new HashMap();
				params.put("uuid", uuid);
				params.put("first_name", firstname);
				params.put("last_name", lastname);
				params.put("street", street);
				params.put("address", address);
				params.put("city", city);
				params.put("state", state);
				params.put("email", email);
				params.put("phone", phone);
				String url = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=update";
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<Object> entity = new HttpEntity<>(params, headers);
				// here depending on the status if we got positive response without any
				// exception then we will perform operation else it will go to catch block
				ResponseEntity<String> status = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				res.sendRedirect(req.getContextPath() + "/customerpage");
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
				return "createCustomer";
			}
		}
		return "login";
	}

}
